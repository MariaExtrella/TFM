# API de Predicción de Radón - Guía para Producción

## Descripción

API REST para predicción de concentración de radón en interiores con 1 hora de anticipación. Integra datos de sensores Arduino con información meteorológica externa.

## Arquitectura

```
┌─────────────┐     ┌─────────────────────────────────────┐
│  Arduino A2 │────▶│            FastAPI                  │
│  (sensores) │     │                                     │
└─────────────┘     │  ┌─────────┐    ┌──────────────┐   │
                    │  │ Caché   │    │   SQLite     │   │
                    │  │ (RAM)   │    │ (histórico)  │   │
┌─────────────┐     │  └────┬────┘    └──────────────┘   │
│Wunderground │◀────│───────┘                             │
│ (meteo API) │     │                                     │
└─────────────┘     └─────────────────────────────────────┘
```

## Instalación con Docker (RECOMENDADO)

Docker garantiza que las versiones de todas las librerías sean exactamente las mismas que en desarrollo, evitando errores de compatibilidad.

### Requisitos
- Docker instalado ([https://docs.docker.com/get-docker/](https://docs.docker.com/get-docker/))
- Docker Compose instalado

### Pasos

```bash
# 1. Clonar/copiar los archivos
cd api_radon_produccion

# 2. Copiar el modelo entrenado
cp /ruta/modelo_radon_1h.pkl ./

# 3. Configurar API key de Wunderground
export WUNDERGROUND_API_KEY="tu_api_key"
export WUNDERGROUND_STATION="EXTREMADURA123"

# 4. Construir y ejecutar
docker-compose up -d

# 5. Verificar que funciona
curl http://localhost:8000/health

# Ver logs
docker-compose logs -f

# Parar
docker-compose down
```

## Instalación sin Docker (alternativa)

```bash
# Crear entorno virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# Instalar dependencias
pip install -r requirements.txt

# Configurar API key de Wunderground en app.py
# CONFIG["wunderground_api_key"] = "TU_API_KEY"

# Copiar modelo entrenado
cp modelo_radon_1h.pkl ./

# Ejecutar
uvicorn app:app --host 0.0.0.0 --port 8000
```

## Endpoints

### Health Check
```bash
GET /health
```

### Predicción
```bash
POST /predict
Content-Type: application/json

{
    "device_id": "arduino_a2_garaje",
    "humedad": 65.5,
    "temperatura": 22.3
}
```

Respuesta:
```json
{
    "device_id": "arduino_a2_garaje",
    "prediccion_bq": 185.3,
    "intervalo_confianza": {"inferior": 147.8, "superior": 222.8},
    "nivel_alerta": "NORMAL",
    "mensaje": "✅ Niveles dentro del rango seguro",
    "accion_recomendada": "Ninguna acción requerida",
    "timestamp": "2026-02-14T10:30:00",
    "meteo_source": "cache"
}
```

### Predicción en lote
```bash
POST /predict/batch
Content-Type: application/json

[
    {"device_id": "arduino_garaje", "humedad": 65.5, "temperatura": 22.3},
    {"device_id": "arduino_sotano", "humedad": 70.2, "temperatura": 20.1}
]
```

## Gestión de caché e histórico

### Invalidar caché meteorológica
```bash
DELETE /cache/meteo
```

## Primera ejecución

 **Importante**: El sistema necesita **10 horas de histórico** antes de poder generar predicciones. 


### SQLite

No necesita instalar nada. SQLite es una base de datos que funciona como un simple archivo (`radon_historico.db`). Python ya lo incluye.


## Configuración

Editar `CONFIG` en `app.py`:

```python
CONFIG = {
    "modelo_path": "modelo_radon_1h.pkl",
    "db_path": "radon_historico.db",
    "wunderground_api_key": "TU_API_KEY_AQUI",
    "wunderground_station": "IGALICIA123",
    "cache_meteo_minutos": 10,
    "historico_horas_mantener": 12,
}
```

## Escalabilidad

### Actual (1-20 dispositivos)
- Caché: Memoria Python
- BD: SQLite
- Despliegue: Servidor único

### Futuro (20-100 dispositivos)
```bash
# Instalar Redis
pip install redis

# Cambiar caché en app.py:
import redis
r = redis.Redis(host='localhost', port=6379)
```

### Futuro (100+ dispositivos)
- Caché: Redis Cluster
- BD: PostgreSQL + TimescaleDB
- Despliegue: Kubernetes

## Integración con Arduino

```cpp
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

void enviarDatos(float humedad, float temperatura) {
    HTTPClient http;
    http.begin("http://TU_SERVIDOR:8000/predict");
    http.addHeader("Content-Type", "application/json");
    
    StaticJsonDocument<200> doc;
    doc["device_id"] = "arduino_a2_garaje";
    doc["humedad"] = humedad;
    doc["temperatura"] = temperatura;
    
    String json;
    serializeJson(doc, json);
    
    int httpCode = http.POST(json);
    
    if (httpCode == 200) {
        String response = http.getString();
        // Parsear respuesta y actuar según nivel_alerta
    }
    
    http.end();
}
```

## Documentación interactiva

Acceder a `http://localhost:8000/docs` para Swagger UI.
